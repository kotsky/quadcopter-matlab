import cv2
import numpy as np
import os
import RPi.GPIO as gpio
import time

###################################################################################################

def adjust_gamma(image, gamma):
    invGamma = 1.0 / gamma
    table = np.array([((i / 255.0) ** invGamma) * 255
	for i in np.arange(0, 256)]).astype("uint8")
 
    return cv2.LUT(image, table)



gpio.setmode(gpio.BCM)

pin_x_l = 12
pin_x_r = 16
pin_y_up = 20
pin_y_d = 21

freq_x = 50
freq_y = 50

gpio.setup(pin_x_l, gpio.OUT)
gpio.setup(pin_x_r, gpio.OUT)

pwmObject_x_l = gpio.PWM(pin_x_l, freq_x)
pwmObject_x_r = gpio.PWM(pin_x_r, freq_x)

pwmObject_x_l.start(0) 
pwmObject_x_r.start(0) 

gpio.setup(pin_y_up, gpio.OUT)
gpio.setup(pin_y_d, gpio.OUT)

pwmObject_y_up = gpio.PWM(pin_y_up, freq_y)
pwmObject_y_d = gpio.PWM(pin_y_d, freq_y)

pwmObject_y_up.start(0)
pwmObject_y_d.start(0)

###################################################################################################

def moved_x(AK_x,Turn_x_l,Turn_x_r):
	
	if AK_x == 1:
		DC_x_l = int(Turn_x_l)
		DC_x_r = int(0)
		pwmObject_x_r.ChangeDutyCycle(DC_x_r)
		pwmObject_x_l.ChangeDutyCycle(DC_x_l)
		
	else:   
		DC_x_r = int(Turn_x_r)
                DC_x_l = int(0)
		pwmObject_x_l.ChangeDutyCycle(DC_x_l)
		pwmObject_x_r.ChangeDutyCycle(DC_x_r)

	
def moved_y(AK_y,Turn_y_up,Turn_y_d):

        if AK_y == 1:
		DC_y_d = int(Turn_y_d)
                DC_y_up = int(0)
                pwmObject_y_up.ChangeDutyCycle(DC_y_up)
                pwmObject_y_d.ChangeDutyCycle(DC_y_d)

        else:
		DC_y_up = int(Turn_y_up)
                DC_y_d = int(0)
                pwmObject_y_d.ChangeDutyCycle(DC_y_d)
                pwmObject_y_up.ChangeDutyCycle(DC_y_up)



###################################################################################################
def main():
    DELAY = 0.001
    diap_x = int(20)
    diap_y = int(10)
    AK_x = 1
    AK_y = 1

    Angle_x = 1
    Koeff_x = 1

    Angle_y = 1
    Koeff_y = 1

###################################################################################################

    capWebcam = cv2.VideoCapture(0)

    print("default resolution = " + str(capWebcam.get(cv2.CAP_PROP_FRAME_WIDTH)) + "x" + str(capWebcam.get(cv2.CAP_PROP_FRAME_HEIGHT)))

    capWebcam.set(cv2.CAP_PROP_FRAME_WIDTH, 320.0)
    capWebcam.set(cv2.CAP_PROP_FRAME_HEIGHT, 240.0)

    intXFrameCenter = int(float(capWebcam.get(cv2.CAP_PROP_FRAME_WIDTH)) / 2.0)
    intYFrameCenter = int(120)

    Position_x = 0
    Position_y = 0

    if capWebcam.isOpened() == False:
        print("error: capWebcam not accessed successfully\n\n")
        os.system("pause")
        return
    # end if

###################################################################################################

    while cv2.waitKey(1) != 27 and capWebcam.isOpened():
        blnFrameReadSuccessfully, imgOriginal = capWebcam.read()

        if not blnFrameReadSuccessfully or imgOriginal is None:
            print("error: frame not read from webcam\n")
            os.system("pause")
            break
        # end if

        gray = cv2.cvtColor(imgOriginal, cv2.COLOR_BGR2GRAY)
        gray = cv2.bilateralFilter(gray, 7, 12, 12)
        med = np.median(gray)

        if med < 11:
            gamma = 2
        elif med < 31:
            gamma = 1.6
        elif med < 51:
            gamma = 1.4
        elif med < 130:
            gamma = 2
        else:
            gamma = 1.3

        imgGamma = adjust_gamma(imgOriginal, gamma)
        imgHSV = cv2.cvtColor(imgGamma, cv2.COLOR_BGR2HSV)

        imgThreshLow = cv2.inRange(imgHSV, np.array([0, 170, 120]), np.array([20, 240, 255]))
        imgThreshHigh = cv2.inRange(imgHSV, np.array([20, 70, 170]), np.array([40, 170, 255]))
        imgThresh = cv2.add(imgThreshLow, imgThreshHigh)

        st1 = cv2.getStructuringElement(cv2.MORPH_RECT, (15, 15), (7, 7))
        st2 = cv2.getStructuringElement(cv2.MORPH_RECT, (11, 11), (5, 5))
        imgThresh = cv2.morphologyEx(imgThresh, cv2.MORPH_CLOSE, st1)
        imgThresh = cv2.morphologyEx(imgThresh, cv2.MORPH_OPEN, st2)
        
        sigma = 33
        low = int(max(0, (1.0 - sigma/100) * med))
        up = int(min(255, (1.0 + sigma/100) * med))

        edged = cv2.Canny(imgThresh, low, up)


       
        img, contours,hierarchy = cv2.findContours(edged.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE )
        try:
            cnt = contours[0]
###################################################################################################

        except Exception:
	    Turn_x_l = int(0)
	    Turn_x_r = int(0)
            if Angle_x == 1:
		if Position_x >= 140:
                    Koeff_x = -1
		    

            else:
                if Position_x <= -140:
                    Koeff_x = -1


            Turn_y_up = int(0)
            Turn_y_d = int(0)
            if Angle_y == 1:
                if Position_y >= 140:
                    Koeff_y = -1


            else:
                if Position_y <= -140:
                    Koeff_y = -1
        
###################################################################################################
	else:
            Koeff = 1
            a,b,w,h = cv2.boundingRect(cnt)
            cv2.rectangle(imgOriginal,(a,b),(a+w,b+h),(0,255,0),2)
            x = a+w/2
            y = b+h/2
            print("ball position x = " + str(x) + ", y = " + str(y))

###################################################################################################

            if x > intXFrameCenter:
                Angle_x = 1
                Turn_x_r = int(0)
                if x < intXFrameCenter + diap_x:
                    Turn_x_l = int((x-160)*0.2)

                else:
                    Turn_x_l = int(0.3 * (x-160))


            else:
                Angle_x = -1
                Turn_x_l = int(0)
                if intXFrameCenter - diap_x < x:
                    Turn_x_r = int(-(x-160)*0.2)

                else:
                    Turn_x_r = int(0.3 * (-(x-160)))

###################################################################################################

            if y > intYFrameCenter:
                Angle_y = 1
                Turn_y_up = int(0)
                if y < intYFrameCenter + diap_y:
                    Turn_y_d = int((y-120)*0.25)

                else:
                    Turn_y_d = int((y-120)*0.35)


            else:
                Angle_y = -1
                Turn_y_d = int(0)
                if intYFrameCenter - diap_y < y:
                    Turn_y_up = int(-(y-120)*0.25)

                else:
                    Turn_y_up = int(0.35*(-(y-120)))


###################################################################################################

	AK_x = Angle_x*Koeff_x
	AK_y = Angle_y*Koeff_y

	moved_x(AK_x,Turn_x_l,Turn_x_r)
	moved_y(AK_y,Turn_y_up,Turn_y_d)

###################################################################################################
        
#        cv2.namedWindow("imgOriginal", cv2.WINDOW_AUTOSIZE)
 #       cv2.namedWindow("imgThresh", cv2.WINDOW_AUTOSIZE)
  #      cv2.imshow("imgOriginal", imgOriginal)
   #     cv2.imshow("imgThresh", imgThresh)
        # end while

    cv2.destroyAllWindows()
    return

###################################################################################################
if __name__ == "__main__":
    main()

